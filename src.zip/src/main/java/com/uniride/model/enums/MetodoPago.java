package com.uniride.model.enums;

public enum MetodoPago {
    EFECTIVO,
    YAPE,
    PLIN,
    TARJETA
}
