package com.uniride.model.enums;

public enum EstadoReserva {
    RESERVADO,
    CANCELADO,
    COMPLETADO
}
