package com.uniride.model.enums;

public enum RolActivo {
    PASAJERO,
    CONDUCTOR
}
