package com.uniride.model.enums;

public enum EstadoPago {
    PENDIENTE,
    PAGADO
}
