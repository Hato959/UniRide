package com.uniride.controller;

public class ResenaController {
}
