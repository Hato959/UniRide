package com.uniride.service;

public class ResenaService {
}
