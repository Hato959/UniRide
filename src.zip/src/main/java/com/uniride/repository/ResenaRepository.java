package com.uniride.repository;

public interface ResenaRepository {
}
