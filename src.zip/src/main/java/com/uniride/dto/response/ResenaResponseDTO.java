package com.uniride.dto.response;

public record ResenaResponseDTO() {
}
