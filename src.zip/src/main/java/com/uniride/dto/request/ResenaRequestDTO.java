package com.uniride.dto.request;

public record ResenaRequestDTO() {
}
