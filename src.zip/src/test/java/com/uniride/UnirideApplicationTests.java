package com.uniride;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnirideApplicationTests {

    @Test
    void contextLoads() {
    }

}
